#### IML Task 2

####### used packages: ########

### Data preparation:
install.packages("remotes")
remotes::install_github("egenn/rtemis")
if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("impute")


### basic ML packages:
packages <- c("e1071", "gbm", "glmnet", "pbapply", "plyr", "ranger", "rpart")
install.packages(packages)

### others: 
install.packages("dplyr")
install.packages("xlsx") # for writing excel tables
install.packages("caret")
install.packages("tidyr")
install.packages("Rfast")
install.packages("rstudioapi")


