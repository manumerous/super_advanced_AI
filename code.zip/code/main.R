#### IML Task 2

## (!!) First run the file 'Task2_features_generation.R' to get the features for fitting and prediction. Then run the code below. 
## Run the code 'Task2_install_packages to install all required packages. 


#### SETUP ####

## Load libraries: 
library(e1071)
library(glmnet)
library(caret)
library(rstudioapi) 

# Set working directory:
setwd(dirname(getActiveDocumentContext()$path))  ## if you are not using RStudio or similar environment in whcih the package Rstudioapi works, set the wd manually to load files below. 

## Set random seed: 
set.seed(500)

## Load data
# subtasks 1 and 2
train_features <- read.csv("./Processed_Features/Train_features_sub12.csv")
test_features <- read.csv("./Processed_Features/Test_features_sub12.csv")
# subtask 3
train_features_sub3 <- read.csv("./Processed_Features/Train_features_sub3.csv")
test_features_sub3 <- read.csv("./Processed_Features/Test_features_sub3.csv")
# train labels
train_labels <- read.csv("./Original_Data/train_labels.csv")


## set global variables
pat.number <- nrow(train_features) # number of patients in train set
pat.number.test <- nrow(test_features) # number of patients in test set 


##### SUBTASK 1 #####

## Solved with svm 
## Labels to predict in subtask 1 are: LABEL_BaseExcess, LABEL_Fibrinogen, LABEL_AST, LABEL_Alkalinephos, LABEL_Bilirubin_total, LABEL_Lactate, LABEL_TroponinI, LABEL_SaO2, LABEL_Bilirubin_direct, LABEL_EtCO2

x <- train_features[,3:75]
xtest <- test_features[,3:75]

## LABEL_BaseExcess:
# fit on train set
y.BaseEx <- train_labels[, "LABEL_BaseExcess"]  
fit_baseEx <- svm(x, y.BaseEx, type = "C-classification", class.weights = c("0" = 1, "1" = 20), scale = FALSE, probability = TRUE)
# predict on test set: 
predict_BaseEx <- predict(fit_baseEx, xtest, probability = TRUE)
LABEL_BaseExcess <- as.data.frame(attr(predict_BaseEx, "probabilities")[,"1"])
# 'probabilities' contains the probability for being label "1"
# we use this probability as predicted "LABEL_BaseEx"


## LABEL_Fibrinogen:
y.Fib <- train_labels[, "LABEL_Fibrinogen"]   
fit_Fib <- svm(x, y.Fib, type = "C-classification", class.weights = c("0" = 1, "1" = 10), scale = FALSE, probability = TRUE)
predict_Fib <- predict(fit_Fib, xtest, probability = TRUE)
LABEL_Fibrinogen <- as.data.frame(attr(predict_Fib, "probabilities")[,"1"])   


## LABEL_AST:
y.Ast <- train_labels[, "LABEL_AST"]  
fit_Ast <- svm(x, y.Ast, type = "C-classification", class.weights = c("0" = 1, "1" = 20), scale = FALSE, probability = TRUE)
predict_Ast <- predict(fit_Ast, xtest, probability = TRUE)
LABEL_AST <- as.data.frame(attr(predict_Ast, "probabilities")[,"1"])


## LABEL_Alkalinephos:
y.Alk <- train_labels[, "LABEL_Alkalinephos"]  
fit_Alk <- svm(x, y.Alk, type = "C-classification", class.weights = c("0" = 1, "1" = 10), scale = FALSE, probability = TRUE)
predict_Alk <- predict(fit_Alk, xtest, probability = TRUE)
LABEL_Alkalinephos <- as.data.frame(attr(predict_Alk, "probabilities")[,"1"])


## LABEL_Bilirubin_total:
y.Biltot <- train_labels[, "LABEL_Bilirubin_total"]  
fit_Biltot <- svm(x, y.Biltot, type = "C-classification", class.weights = c("0" = 1, "1" = 10), scale = FALSE, probability = TRUE)
predict_Biltot <- predict(fit_Biltot, xtest, probability = TRUE)
LABEL_Bilirubin_total <- as.data.frame(attr(predict_Biltot, "probabilities")[,"1"])


## LABEL_Lactate
y.Lact <- train_labels[1:pat.number, "LABEL_Lactate"]  
fit_Lact <- svm(x, y.Lact, type = "C-classification", class.weights = c("0" = 1, "1" = 10), scale = FALSE, probability = TRUE)
predict_Lact <- predict(fit_Lact, xtest, probability = TRUE)
LABEL_Lactate <- as.data.frame(attr(predict_Lact, "probabilities")[,"1"])


## LABEL_TroponinI
y.Trop <- train_labels[1:pat.number, "LABEL_TroponinI"]  
fit_Trop <- svm(x, y.Trop, type = "C-classification", class.weights = c("0" = 1, "1" = 10), scale = FALSE, probability = TRUE)
predict_Trop <- predict(fit_Trop, xtest, probability = TRUE)
LABEL_TroponinI <- as.data.frame(attr(predict_Trop, "probabilities")[,"1"])


## LABEL_SaO2
y.Sa <- train_labels[1:pat.number, "LABEL_SaO2"]  
fit_Sa <- svm(x, y.Sa, type = "C-classification", class.weights = c("0" = 1, "1" = 10), scale = FALSE, probability = TRUE)
predict_Sa <- predict(fit_Sa, xtest, probability = TRUE)
LABEL_SaO2 <- as.data.frame(attr(predict_Sa, "probabilities")[,"1"])


## LABEL_Bilirubin_direct
y.Bildir <- train_labels[1:pat.number, "LABEL_Bilirubin_direct"]  
fit_Bildir <- svm(x, y.Bildir, type = "C-classification", class.weights = c("0" = 1, "1" = 10), scale = FALSE, probability = TRUE)
predict_Bildir <- predict(fit_Bildir, xtest, probability = TRUE)
LABEL_Bilirubin_direct <- as.data.frame(attr(predict_Bildir, "probabilities")[,"1"])


## LABEL_EtCO2 
y.Etco <- train_labels[1:pat.number, "LABEL_EtCO2"]  
fit_Etco <- svm(x, y.Etco, type = "C-classification", class.weights = c("0" = 1, "1" = 10), scale = FALSE, probability = TRUE)
predict_Etco <- predict(fit_Etco, xtest, probability = TRUE)
LABEL_EtCO2 <- as.data.frame(attr(predict_Etco, "probabilities")[,"1"])



## collect data and export to csv: 
pid.test <- test_features$max_pid

sol1 <- cbind(pid.test, LABEL_BaseExcess, LABEL_Fibrinogen, LABEL_AST, LABEL_Alkalinephos, LABEL_Bilirubin_total, LABEL_Lactate, LABEL_TroponinI, LABEL_SaO2, LABEL_Bilirubin_direct, LABEL_EtCO2) 
sol1 <- round(sol1, digits = 3)
colnames(sol1) <- c("pid", "LABEL_BaseExcess", "LABEL_Fibrinogen", "LABEL_AST", "LABEL_Alkalinephos", "LABEL_Bilirubin_total", "LABEL_Lactate", "LABEL_TroponinI", "LABEL_SaO2", "LABEL_Bilirubin_direct", "LABEL_EtCO2")
write.csv(sol1, file = "./Results/sol1.csv")
# sol1 contains the results for subtask 1



################## SUBTASK 2 - PREDICT SEPSIS ################

## Solved with SVM 
## Label to predict is LABEL_Sepsis

x <- train_features[,3:75]
xtest <- test_features[,3:75]

## LABEL_Sepsis
# train svm:
y.Sepsis <- train_labels[, "LABEL_Sepsis"]
fit_Sepsis <- svm(x, y.Sepsis, type = "C-classification", class.weights = c("0" = 1, "1" = 20), kernel = "radial", scale = FALSE, probability = TRUE)
## predict on test set: 
predict_Sepsis <- predict(fit_Sepsis, xtest, probability = TRUE)
LABEL_Sepsis <- as.data.frame(attr(predict_Sepsis, "probabilities")[,"1"])
head(LABEL_Sepsis)

## collect data and export to csv:
pid.test <- test_features$max_pid
sol2 <- as.data.frame(cbind(pid.test, LABEL_Sepsis))
sol2 <- round(sol2, digits = 3)
colnames(sol2) <- c("pid", "LABEL_Sepsis")
write.csv(sol2, file = "./Results/sol2.csv")
# sol2 contains the predicted results for subtask 2


### with the altered settings (kernel = radial, class.weight = 1:20) we obtain a score of 0.699
### for further improvements try around with the cost = 1,2,3... and gamma for further improvement





##### SUBTASK 3 - PREDICT MEAN VALUES OF KEY VITAL SIGNS #####
## we use data from 5 vital signs imputed with knn imputation
## further we apply Lasso regression instead of svm
## before fits below CV was performed to find the optimal lambda and the R^2 & RSME evaluated: see functions at end of Subtask 3 for example LABEL_RRate (commented out)

## Labels to predict are: LABEL_RRate, LABEL_ABPm, LABEL_SpO2, LABEL_Heartrate

## Optimal found lambdas were: 
# RRate: 0.01995
# ABPm: 0.01994
# SpO2: 0.01258
# Heartrate: 0.03981


##### Lasso regression for every LABEL_..

## RRate
column = c("LABEL_RRate")
lambda_best = 0.01995

train = cbind(train_labels[,column], train_features_sub3[,3:63])
test = cbind(test_features_sub3[,3:63])
x = as.matrix(train[,2:62])
y_train = as.matrix(train[,1])
x_test = as.matrix(test[,1:61])
y_test = as.matrix(test[,1])

# scale and center data: 
cols <- c(2:62)
pre_proc_val <- preProcess(train[,cols], method = c("center", "scale"))
train[,cols] = predict(pre_proc_val, train[,cols])
test[,cols] = predict(pre_proc_val, test)
summary(train)

# fit Lasso regression with found lambda_best
lasso_model <- glmnet(x, y_train, alpha = 1, lambda = lambda_best, standardize = TRUE)
# train set fit and evaluation:
predictions_train <- predict(lasso_model, s = lambda_best, newx = x)
eval_results(y_train, predictions_train, train)
# test set fit and evaluation:
predictions_test <- predict(lasso_model, s = lambda_best, newx = x_test)

# Prediction for LABEL_..
LABEL_RRate <- predictions_test 



## ABPm
column = c("LABEL_ABPm")
lambda_best = 0.01995

train = cbind(train_labels[,column], train_features_sub3[,3:63])
test = cbind(test_features_sub3[,3:63])
x = as.matrix(train[,2:62])
y_train = as.matrix(train[,1])
x_test = as.matrix(test[,1:61])
y_test = as.matrix(test[,1])

# scale and center data: 
cols <- c(2:62)
pre_proc_val <- preProcess(train[,cols], method = c("center", "scale"))
train[,cols] = predict(pre_proc_val, train[,cols])
test[,cols] = predict(pre_proc_val, test)
summary(train)

# fit Lasso regression with found lambda_best
lasso_model <- glmnet(x, y_train, alpha = 1, lambda = lambda_best, standardize = TRUE)
# train set fit and evaluation:
predictions_train <- predict(lasso_model, s = lambda_best, newx = x)
eval_results(y_train, predictions_train, train)
# test set fit and evaluation:
predictions_test <- predict(lasso_model, s = lambda_best, newx = x_test)

# Prediction for LABEL_..
LABEL_ABPm <- predictions_test 



## SpO2
column = c("LABEL_SpO2")
lambda_best = 0.01258

train = cbind(train_labels[,column], train_features_sub3[,3:63])
test = cbind(test_features_sub3[,3:63])
x = as.matrix(train[,2:62])
y_train = as.matrix(train[,1])
x_test = as.matrix(test[,1:61])
y_test = as.matrix(test[,1])

# scale and center data: 
cols <- c(2:62)
pre_proc_val <- preProcess(train[,cols], method = c("center", "scale"))
train[,cols] = predict(pre_proc_val, train[,cols])
test[,cols] = predict(pre_proc_val, test)
summary(train)

# fit Lasso regression with found lambda_best
lasso_model <- glmnet(x, y_train, alpha = 1, lambda = lambda_best, standardize = TRUE)
# train set fit and evaluation:
predictions_train <- predict(lasso_model, s = lambda_best, newx = x)
eval_results(y_train, predictions_train, train)
# test set fit and evaluation:
predictions_test <- predict(lasso_model, s = lambda_best, newx = x_test)

# Prediction for LABEL_..
LABEL_SpO2 <- predictions_test 



## Heartrate
column = c("LABEL_Heartrate")
lambda_best = 0.03981

train = cbind(train_labels[,column], train_features_sub3[,3:63])
test = cbind(test_features_sub3[,3:63])
x = as.matrix(train[,2:62])
y_train = as.matrix(train[,1])
x_test = as.matrix(test[,1:61])
y_test = as.matrix(test[,1])

# scale and center data: 
cols <- c(2:62)
pre_proc_val <- preProcess(train[,cols], method = c("center", "scale"))
train[,cols] = predict(pre_proc_val, train[,cols])
test[,cols] = predict(pre_proc_val, test)
summary(train)

# fit Lasso regression with found lambda_best
lasso_model <- glmnet(x, y_train, alpha = 1, lambda = lambda_best, standardize = TRUE)
# train set fit and evaluation:
predictions_train <- predict(lasso_model, s = lambda_best, newx = x)
eval_results(y_train, predictions_train, train)
# test set fit and evaluation:
predictions_test <- predict(lasso_model, s = lambda_best, newx = x_test)

# Prediction for LABEL_..
LABEL_Heartrate <- predictions_test 


## bind and export labels of subtask 3
sol3 <- cbind(pid.test, LABEL_RRate, LABEL_ABPm, LABEL_SpO2, LABEL_Heartrate) 
sol3 <- round(sol3, digits = 3)
colnames(sol3) <- c("pid", "LABEL_RRate", "LABEL_ABPm", "LABEL_SpO2", "LABEL_Heartrate")
write.csv(sol3, file = "./Results/sol3.csv")



# #### Evaluation metric Rsquared and RMSE calculation function: ####
# eval_results <- function(true, predicted, df) {
#   SSE <- sum((predicted - true)^2)
#   SST <- sum((true - mean(true))^2)
#   R_square <- 1 - SSE / SST
#   RMSE = sqrt(SSE/nrow(df))
# 
#   # Model performance metrics
#   data.frame(
#     RMSE = RMSE,
#     Rsquare = R_square
#   )
# }
# 
# ##### Lasso regression incl. search function for opt. lambda for every LABEL_..
# 
# ## RRate
# column = c("LABEL_RRate")
# 
# train = cbind(train_labels[,column], train_features_sub3[,3:63])
# test = cbind(test_labels[,column], test_features_sub3[,3:63])
# x = as.matrix(train[,2:62])
# y_train = as.matrix(train[,1])
# x_test = as.matrix(test[,2:62])
# y_test = as.matrix(test[,1])
# 
# # sclale and center data: 
# cols <- c(2:62)
# pre_proc_val <- preProcess(train[,cols], method = c("center", "scale"))
# 
# train[,cols] = predict(pre_proc_val, train[,cols])
# test[,cols] = predict(pre_proc_val, test[,cols])
# summary(train)
# 
# ## select lambda in CV: 
# lambdas <- 10^seq(2, -3, by = -.1)
# # Setting alpha = 1 implements lasso regression
# lasso_reg <- cv.glmnet(x, y_train, alpha = 1, lambda = lambdas, standardize = TRUE, nfolds = 5)
# # Best 
# lambda_best <- lasso_reg$lambda.min 
# lambda_best # the lambda_best is 0.01995
# 
# # fit Lasso regression with found lambda_best
# lasso_model <- glmnet(x, y_train, alpha = 1, lambda = lambda_best, standardize = TRUE)
# # train set fit and evaluation:
# predictions_train <- predict(lasso_model, s = lambda_best, newx = x)
# eval_results(y_train, predictions_train, train)
# # test set fit and evaluation:
# predictions_test <- predict(lasso_model, s = lambda_best, newx = x_test)
# eval_results(y_test, predictions_test, test)
# 
# LABEL_RRate <- predictions_test # generate new csv file below with this value
# 
# 




###### MERGE SOLUTIONS OF SUBTASKS 1, 2 AND 3 #######
final <- cbind(sol1, sol2[,-1], sol3[,-1])
write.csv(final, file = "./Results/final.csv", row.names = FALSE)
# 'final' contains the result for the final submission online





