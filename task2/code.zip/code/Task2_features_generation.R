#### IML Task 2 - FEATURE GENERATION

## Run the code 'Task2_install_packages to install all required packages. 

#### SETUP ####

## Load libraries: 
library(xlsx)
library(rtemis)
library(dplyr)
library(Rfast)
library(impute)
library(dplyr)
library(tidyr)
library(rstudioapi)

# Set working directory:
setwd(dirname(getActiveDocumentContext()$path))  ## if you are not using RStudio or similar environment in which the package Rstudioapi works, set the wd manually to load files below. 

## Set random seed: 
set.seed(500)

## Load data
train_data <- read.csv("./Original_data/train_features.csv")
train_labels <- read.csv("./Original_data/train_labels.csv")
test_data <- read.csv("./Original_data/test_features.csv")

## set global variables
pat.number <- nrow(train_data)/12 # number of patients in train set
pat.number.test <- nrow(test_data)/12 # number of patients in test set 



##### GENERATE FEATURES SUBTASK 1 AND 2 #####

# For subtasks 1 and 2 the 12 columns per patient were summed up and the colMax, colMean and colVariance were taken
# From this results one row per patient 

## Normalize data: 

# set NA to 0
train_data[is.na(train_data)] <- 0
# normalize values in range [0:1] per column, except the first 2 columns with time and age:
train_normal <- cbind(train_data[,1:2], apply(train_data[,3:37], 2, function(x) {(x - min(x, na.rm = T))/(max(x, na.rm = T) - min(x, na.rm = T))}))

# set NA to 0
test_data[is.na(test_data)] <- 0
# normalize values in range [0:1] per column, except the first 2 columns with time and age:
test_normal <- cbind(test_data[,1:2], apply(test_data[,3:37], 2, function(x) {(x - min(x, na.rm = T))/(max(x, na.rm = T) - min(x, na.rm = T))}))


#### COLMAX ####

## Train set colMax ##
p <- c(1) # attention always reset before starting loop! 
patients.colmax <- data.frame()
for (i in 1:pat.number){
  pat <- t(colMax(filter(train_normal, pid == train_normal$pid[p])[,-2]))
  patients.colmax <- rbind(patients.colmax, pat)
  p <- c(p + 12)
}

# change colnames to max_colname
colnames(patients.colmax) <- paste("max", colnames(patients.colmax), sep = "_")

## Test set colMax ##
p <- c(1) # attention always reset before starting loop! 
patients.colmax.test <- data.frame()
for (i in 1:pat.number.test){
  pat.test <- t(colMax(filter(test_normal, pid == test_normal$pid[p])[,-2]))
  patients.colmax.test <- rbind(patients.colmax.test, pat.test)
  p <- c(p + 12)
}

# change colnames to max_colname
colnames(patients.colmax.test) <- paste("max", colnames(patients.colmax.test), sep = "_")


#### COLMEAN ####

## Train set colmean ##
p <- c(1) # attention always reset before starting loop! 
patients.colmean <- data.frame()
for (i in 1:pat.number){
  pat <- t(colMeans(filter(train_normal, pid == train_normal$pid[p])[,3:37]))
  patients.colmean <- rbind(patients.colmean, pat)
  p <- c(p + 12)
}

# change colnames to mean_colname
colnames(patients.colmean) <- paste("mean", colnames(patients.colmean), sep = "_")


## Test set colmean ## 
p <- c(1) # attention always reset before starting loop! 
patients.colmean.test <- data.frame()
for (i in 1: pat.number.test){
  pat <- t(colMeans(filter(test_normal, pid == test_normal$pid[p])[,3:37]))
  patients.colmean.test <- rbind(patients.colmean.test, pat)
  p <- c(p + 12)
}

# change colnames to mean_colname
colnames(patients.colmean.test) <- paste("mean", colnames(patients.colmean.test), sep = "_")


#### COL VARIANCE ####
# take the non-normalized data as input incl. NA values 
# only the variables with few Na values are used

cols <- c("Temp", "RRate", "ABPm", "Heartrate", "ABPs")

## Train set
p <- c(1)
patients.var <- data.frame()
for (i in 1:pat.number){
  pat <- as.matrix(filter(train_data, pid == train_data$pid[p]))
  colvars <- colVars(pat[,cols])
  patients.var <- rbind(patients.var, colvars)
  p <- c(p + 12)
}

colnames(patients.var) = c("var.Temp", "var.RRate", "var.ABPm", "var.Heartrate", "var.ABPs")
pid <- unique(train_data[,"pid"])

## Test set
p <- c(1)
patients.var.test <- data.frame()
for (i in 1:pat.number.test){
  pat <- as.matrix(filter(test_data, pid == test_data$pid[p]))
  colvars <- colVars(pat[,cols])
  patients.var.test <- rbind(patients.var.test, colvars)
  p <- c(p + 12)
}

colnames(patients.var.test) = c("var.Temp", "var.RRate", "var.ABPm", "var.Heartrate", "var.ABPs")
pid.test <- unique(test_data[,"pid"])


## normalize the data and set NA to 0: 
# train data:
patients.var[is.na(patients.var)] <- 0
patients.variance <- cbind(pid, apply(patients.var, 2, function(x) {(x - min(x, na.rm = T))/(max(x, na.rm = T) - min(x, na.rm = T))}))

# test data:
patients.var.test[is.na(patients.var.test)] <- 0
patients.variance.test <- cbind(pid.test, apply(patients.var.test, 2, function(x) {(x - min(x, na.rm = T))/(max(x, na.rm = T) - min(x, na.rm = T))}))


#### Bind colMax, colMeans and colVars columns as features for subtask 1 and 2 ####

features_train_sub12 <- cbind(patients.colmax, patients.colmean[,-1], patients.variance[,-1])
features_test_sub12 <- cbind(patients.colmax.test, patients.colmean.test[-1], patients.variance.test[,-1])

write.csv(features_train_sub12, file = "./Processed_Features/Train_features_sub12.csv")
write.csv(features_test_sub12, file = "./Processed_Features/Test_features_sub12.csv")




######## GENERATE FEATURES SUBTASK 3 #######

## In subtaks 3 the data from above was insufficient to predict mean values 
## thus we used knn data imputation for the vital signs to be predicted in this task and applied the svm on all 12 hourly lines per patient. 

## Labels to predict are: LABEL_RRate, LABEL_ABPm, LABEL_SpO2, LABEL_Heartrate

### Impute data: 
# load the data with NA vlaues again and impute: 

# train set
train_data_withNa <- as.matrix((read.csv("./Original_data/train_features.csv"))[,c("pid", "Age", "Temp", "RRate", "ABPm", "ABPd","SpO2", "Heartrate", "ABPs")])
train_data_sub3 <- as.data.frame((impute.knn(train_data_withNa, k = 15, colmax = 0.8, rowmax = 0.6))$data)
# test set
test_data_withNa <- as.matrix((read.csv("./Original_data/test_features.csv"))[,c("pid", "Age", "Temp", "RRate", "ABPm", "ABPd","SpO2", "Heartrate", "ABPs")])
test_data_sub3 <- as.data.frame((impute.knn(test_data_withNa, k = 15, colmax = 0.8, rowmax = 0.6))$data)

## order data to one row per patient with each time stamp as variable: 
timestamp <- c(1:12)
DF_train = cbind(train_data_sub3, timestamp)
DF_test = cbind(test_data_sub3, timestamp)
vitals = c("Temp", "RRate", "ABPm", "ABPd", "SpO2", "Heartrate", "ABPs")
# train data
features_train_sub3 <- DF_train %>%
  pivot_wider(id_cols = pid, values_from = all_of(vitals), names_from = timestamp)
# test data
features_test_sub3 <- DF_test %>%
  pivot_wider(id_cols = pid, values_from = all_of(vitals), names_from = timestamp)


### Export feature data for subtask 3
write.csv(features_train_sub3, file = "./Processed_Features/Train_features_sub3.csv")
write.csv(features_test_sub3, file = "./Processed_Features/Test_features_sub3.csv")

